package com.example.question0_3.Enum;

public enum LoginMessages {
    REPEATED_USERNAME,
    INCORRECT_INFORMATION,
    SUCCESS;
}
